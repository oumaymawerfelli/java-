package tn.esprit.gestionzoo.exceptions;

public class InvalidAgeException extends Exception{
    public InvalidAgeException(){
        super("Invalid age !!!");
    }

    public InvalidAgeException(String msg){
        super(msg);
    }
}
