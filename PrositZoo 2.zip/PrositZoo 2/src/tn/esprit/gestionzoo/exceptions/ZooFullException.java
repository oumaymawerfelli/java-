package tn.esprit.gestionzoo.exceptions;

public class ZooFullException extends Exception{
    public ZooFullException(){
        super("Zoo is full !!!");
    }
}
