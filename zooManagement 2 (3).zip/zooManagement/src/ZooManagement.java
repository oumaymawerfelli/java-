import Animal;
import Zoo;

public class ZooManagement {
    public static void main(String[] args){


        Zoo myZoo = new Zoo("myZoo", "Tunis");
        Zoo myZoo1 = new Zoo("myZoo1", "Sousse");
        Zoo myZoo2 = new Zoo("myZoo2", "Sfax");


        //myZoo.displayZoo();
        //myZoo1.displayZoo();
        //myZoo2.displayZoo();



        System.out.println(myZoo);

        Animal lion = new Animal("Chat", "Simba",9, true);
        Animal oiseau = new Animal("Ovipare", "Bolbol",1, false);
        Animal tiger = new Animal("Chat", "Charokhan",4, true);
        Animal chien = new Animal("Chien", "Rex",3, true);

        Animal abc = new Animal("Chat", "Simba",9, true);

        myZoo.addAnimal(lion);
        myZoo.addAnimal(oiseau);
        //myZoo.addAnimal(tiger);
        //myZoo.addAnimal(chien);

        System.out.println(myZoo.searchAnimal(abc));

        Zoo.comparerZoo(myZoo,myZoo1);
    }
}
